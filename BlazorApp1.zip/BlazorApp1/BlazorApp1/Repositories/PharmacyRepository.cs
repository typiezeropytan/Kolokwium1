﻿using System.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;
using BlazorApp1.Models;
using WebApplication1.Service;

namespace WebApplication1.Repositories
{
    public class PharmacyRepository : IPharmacyRepository
    {
        
        private readonly IConfiguration _configuration;
        
        public PharmacyRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<bool> DoesMedicationExist(int id)
        {
            using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);            await using SqlCommand com = new SqlCommand();

            com.Connection = con;
            com.CommandText = "SELECT 1 FROM Medication WHERE IdMedication = @Id";
            com.Parameters.AddWithValue("@Id", id);

            await con.OpenAsync();
        
            return await com.ExecuteScalarAsync() is not null;
        }
        
        public async Task<bool> DoesPrescriptionExist(int id)
        {
            await using SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));
            await using SqlCommand com = new SqlCommand();

            com.Connection = conn;
            com.CommandText = "SELECT 1 FROM Prescription WHERE IdMedication = @Id";
            com.Parameters.AddWithValue("@Id", id);

            await conn.OpenAsync();
        
            return await com.ExecuteScalarAsync() is not null;
        }

        public IEnumerable<Prescription> GetPrescriptions(int id)
        {
            using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
            con.Open();
        
            using var cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "SELECT IdPrescription, Date, DueDate, IdPatient, IdDoctor FROM Prescription ORDER BY Date";
        
            var dr = cmd.ExecuteReader();
            var prescriptions = new List<Prescription>();
            
            while (dr.Read())
            {
                var grade = new Prescription
                {
                    IdPrescription = (int)dr["idPrescription"],
                    Date = dr["Date"].ToString(),
                    DueDate = dr["DueDate"].ToString(),
                    IdPatient = (int)dr["IdPatient"],
                    IdDoctor = (int)dr["IdDoctor"],
                };
                prescriptions.Add(grade);
            }
        
            return prescriptions;
        }

        public int DeletePatient(int id)
        {
            using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
            con.Open();
        
            using var cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "DELETE FROM Patient WHERE IdPatient = @IdPatient";
            cmd.CommandText = "DELETE FROM Prescription_Medicament WHERE IdPrescprition in (SELECT IdPrescription WHERE IdPatient = @IdPatient)";
            cmd.CommandText = "DELETE FROM Prescription WHERE IdPatient = @IdPatient";
            cmd.Parameters.AddWithValue("@IdStudent", id);
        
            var affectedCount = cmd.ExecuteNonQuery();
            return affectedCount;
        }
    }
    
}