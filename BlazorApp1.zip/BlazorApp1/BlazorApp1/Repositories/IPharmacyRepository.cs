﻿using System.Threading.Tasks;
using BlazorApp1.Models;

namespace WebApplication1.Repositories
{
    public interface IPharmacyRepository
    {
        Task<bool> DoesMedicationExist(int id);
        Task<bool> DoesPrescriptionExist(int id);
        IEnumerable<Prescription> GetPrescriptions(int idMedicament);
        int DeletePatient(int idPatient);
    }
}