﻿using System;
using System.Threading.Tasks;
using BlazorApp1.Models;
using WebApplication1.Controllers;
using WebApplication1.Repositories;

namespace WebApplication1.Service
{
    public class PharmacyService : IPharmacyService
    {
        private readonly IPharmacyRepository _pharmacyRepository;
        
        public PharmacyService(IPharmacyRepository repository)
        {
            _pharmacyRepository = repository;
        }

        Task<bool> DoesMedicationExist(int id)
        {
            throw new NotImplementedException();
        }
        
        Task<bool> DoesPrescriptionExist(int id)
        {
            throw new NotImplementedException();
        }

        IEnumerable<Prescription> getPrescriptions(int idMedicament)
        {
            throw new NotImplementedException();
        }

        int DeletePatient(int idPatient)
        {
            throw new NotImplementedException();
        }
    }
}