﻿using System.Threading.Tasks;
using BlazorApp1.Models;
using WebApplication1.Models;

namespace WebApplication1.Service
{
    public abstract class IPharmacyService
    {
        Task<bool> DoesMedicationExist(int id)
        {
            throw new NotImplementedException();
        }
        
        Task<bool> DoesPrescriptionExist(int id)
        {
            throw new NotImplementedException();
        }

        IEnumerable<Prescription> getPrescriptions(int idMedicament)
        {
            throw new NotImplementedException();
        }

        public int DeletePatient(int idPatient)
        {
            throw new NotImplementedException();
        }
    }
}