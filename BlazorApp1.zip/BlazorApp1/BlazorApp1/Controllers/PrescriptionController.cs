﻿using System;
using System.Threading.Tasks;
using BlazorApp1.Models;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Service;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PrescriptionController : ControllerBase
    {
        private readonly IPharmacyService _pharmacyService;

        public PrescriptionController(IPharmacyService pharmacyService)
        {
            _pharmacyService = pharmacyService;
        }

        [HttpGet]
        public Task<IActionResult> GetPrescriptions(Prescription prescription)
        {
            try
            {
                return Task.FromResult<IActionResult>(Ok($"Prescription has been found"));
            }
            catch (Exception e)
            {
                return Task.FromResult<IActionResult>(NotFound(e.StackTrace));
            }
        }

        [HttpDelete("{id:int}")]
        public IActionResult DeleteStudent(int id)
        {
            try
            {
                var affectedCount = _pharmacyService.DeletePatient(id);
                return NoContent();
            }
            catch (Exception e)
            {
                return NotFound(e.StackTrace);
            }
        }
    }
}